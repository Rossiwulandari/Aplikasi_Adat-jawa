package com.example.adat_jawa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
