// lib/screens/main_screen.dart
import 'package:flutter/material.dart';
import 'detail_screen.dart';  // Import halaman DetailScreen

class MainScreen extends StatelessWidget {
  final List<Map<String, String>> traditions = [
    {
      'name': 'Ngaben',
      'description': 'Upacara pembakaran mayat dalam agama Hindu Bali.',
      'image': 'images/ngaben.jpg',
      'detailed_description': '''
Ngaben adalah upacara pembakaran jenazah yang dilakukan oleh masyarakat Hindu Bali sebagai bentuk penghormatan terakhir terhadap orang yang telah meninggal.
Proses ini bertujuan untuk membebaskan roh almarhum agar bisa kembali ke dunia roh dan bersatu dengan Tuhan. Upacara ini biasanya dilakukan secara besar-besaran
dan melibatkan seluruh anggota keluarga serta masyarakat sekitar. Ngaben sangat penting dalam tradisi Hindu Bali dan merupakan simbol dari perjalanan kehidupan manusia.
'''
    },
    {
      'name': 'Sekaten',
      'description': 'Perayaan hari kelahiran Nabi Muhammad SAW.',
      'image': 'images/sekaten.jpg',
      'detailed_description': '''
Sekaten adalah tradisi yang dilakukan di Yogyakarta dan Surakarta (Solo) untuk memperingati kelahiran Nabi Muhammad SAW. 
Perayaan ini dilaksanakan dengan serangkaian kegiatan seperti pasar malam, konser musik gamelan, serta doa bersama. 
Sekaten juga menjadi ajang untuk mempererat hubungan antar masyarakat dan memperkenalkan kebudayaan Jawa kepada masyarakat luas.
'''
    },
    {
      'name': 'Rebo Wekasan',
      'description': 'Hari terakhir bulan Safar dalam kalender Islam.',
      'image': 'images/rebo_wekasan.jpg',
      'detailed_description': '''
Rebo Wekasan adalah tradisi Jawa yang dilaksanakan pada hari Rabu terakhir bulan Safar. 
Tradisi ini dipercaya untuk mengusir bala dan malapetaka yang bisa menimpa seseorang. 
Biasanya, masyarakat akan mengadakan doa dan selametan untuk memohon keselamatan dan keberkahan hidup. 
Di beberapa daerah, Rebo Wekasan juga diiringi dengan ritual adat yang melibatkan masyarakat setempat.
'''
    },
    {
      'name': 'Selametan',
      'description': 'Upacara syukuran yang dilakukan oleh orang Jawa.',
      'image': 'images/selametan.jpg',
      'detailed_description': '''
Selametan adalah salah satu tradisi penting dalam kehidupan masyarakat Jawa. 
Selametan dilakukan sebagai bentuk syukur kepada Tuhan atas nikmat yang telah diberikan atau untuk memohon keselamatan. 
Dalam tradisi ini, masyarakat berkumpul untuk makan bersama dan membaca doa-doa yang dipimpin oleh seorang pemuka agama atau orang yang dituakan.
Selametan bisa dilakukan pada berbagai acara, seperti pernikahan, kelahiran, dan bahkan pada hari-hari tertentu yang dianggap penting dalam kalender Jawa.
'''
    },
    {
      'name': 'Sedekah Laut',
      'description': 'Tradisi ritual laut yang dilakukan oleh nelayan.',
      'image': 'images/sedekah_laut.jpg',
      'detailed_description': '''
Sedekah Laut adalah tradisi yang dilakukan oleh masyarakat pesisir, terutama nelayan, sebagai ungkapan syukur atas hasil laut yang didapatkan. 
Ritual ini biasanya diadakan dengan memberikan sesaji berupa makanan, hasil bumi, atau hewan untuk laut sebagai bentuk terima kasih kepada Tuhan dan alam. 
Sedekah Laut juga bertujuan untuk memohon keselamatan bagi nelayan agar terhindar dari bahaya saat melaut. 
Tradisi ini sering kali diiringi dengan upacara adat yang melibatkan seluruh anggota komunitas nelayan setempat.
'''
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tradisi Adat Jawa'),
      ),
      body: ListView.builder(
        itemCount: traditions.length,
        itemBuilder: (context, index) {
          return Card(
            child: ListTile(
              leading: Image.asset(
                traditions[index]['image']!,
                width: 50,
                height: 50,
                fit: BoxFit.cover,
              ),
              title: Text(traditions[index]['name']!),
              subtitle: Text(traditions[index]['description']!),
              onTap: () {
                // Navigasi ke halaman detail
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => DetailScreen(
                      traditionName: traditions[index]['name']!,
                      traditionDescription: traditions[index]['detailed_description']!,
                      traditionImage: traditions[index]['image']!,
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
